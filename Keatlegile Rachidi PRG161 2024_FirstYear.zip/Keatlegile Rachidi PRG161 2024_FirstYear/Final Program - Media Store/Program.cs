﻿using System;
using System.Collections.Generic;
using System.Linq;
 
namespace RewindMediaStore
{
    enum MediaType
    {
        VHS,
        CD,
        DVD
    }

    class Customer
    {
        public string Name { get; set; }
        public int RegistrationYear { get; set; }
        public int Rentals { get; set; }
        public double MoneySpent { get; set; }

        public override string ToString()
        {
            return $"Name: {Name}, Registration Year: {RegistrationYear}, Rentals: {Rentals}, Money Spent: {MoneySpent:C}";
        }
    }

    class Title
    {
        public string Name { get; set; }
        public MediaType Type { get; set; }
        public string Genre { get; set; }
        public double Price { get; set; }

        public override string ToString()
        {
            return $"Name: {Name}, Type: {Type}, Genre: {Genre}, Price: {Price:C}";
        }
    }

    class Rental
    {
        public Customer Customer { get; set; }
        public List<Title> Titles { get; set; }
        public double TotalCost { get; set; }

        public override string ToString()
        {
            return $"Customer: {Customer.Name}, Titles: {string.Join(", ", Titles.Select(t => t.Name))}, Total Cost: {TotalCost:C}";
        }

        class Program
    {
        static List<Customer> customers = new List<Customer>();
        static List<Title> titles = new List<Title>();
        static List<Rental> rentals = new List<Rental>();

        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Rewind Media Store!");

            AddTitles();

            while (true)
            {
                Console.WriteLine("\nMain Menu:");
                Console.WriteLine("1. Admin Login");
                Console.WriteLine("2. Rent Titles");
                Console.WriteLine("3. Exit");

                int choice = GetChoice(3);

                switch (choice)
                {
                    case 1:
                        AdminLogin();
                        break;
                    case 2:
                        RentTitles();
                        break;
                    case 3:
                        return;
                }
            }
        }

        static void AddTitles()
        {
            string[] vhsTitles = { " Back to the Future", "Star Wars", "Indiana Jones", "Jaws", "E.T.", "Blade Runner", "Alien", "Ghostbusters", "The Terminator", "Die Hard" };
            string[] cdTitles = { "Thriller by Micheal Jackson", "Back to Black by Amy Winehouse", "ASTROWORLD by Travis Scott", "Amukelani by Kelvin Momo", "The Burning Tree by A-Reece", "One In A Million by Aaliyah", "Lemonade by Beyonce", "Don't be Cruel by Bobby Brown", "Never Say Never by Brandy", "It Ain't Safe No More... by Busta Rhymes" };
            string[] dvdTitles = { "The Matrix", "Gladiator", "Titanic", "The Lord of the Rings", "Harry Potter", "The Godfather", "Forrest Gump", "Pulp Fiction", "Schindler's List", "The Lion King" };

            foreach (var title in vhsTitles)
            {
                titles.Add(new Title { Name = title, Type = MediaType.VHS, Genre = "Sci-Fi", Price = 215 });
            }

            foreach (var title in cdTitles)
            {
                titles.Add(new Title { Name = title, Type = MediaType.CD, Genre = "Music", Price = 128 });
            }

            foreach (var title in dvdTitles)
            {
                titles.Add(new Title { Name = title, Type = MediaType.DVD, Genre = "Movie", Price = 165 });
            }
        }

        static void AdminLogin()
        {
            Console.Write("Enter admin username: ");
            string username = Console.ReadLine();
            Console.Write("Enter admin password: ");
            string password = Console.ReadLine();

            if (username == "admin" && password == "password")
            {
                AdminMenu();
            }
            else
            {
                Console.WriteLine("Invalid credentials. Returning to main menu.");
            }
        }

        static void AdminMenu()
        {
            while (true)
            {
                Console.WriteLine("\nAdmin Menu:");
                Console.WriteLine("1. Add New Customer");
                Console.WriteLine("2. Add New Title");
                Console.WriteLine("3. View All Customers");
                Console.WriteLine("4. View All Rentals");
                Console.WriteLine("5. Logout");

                int choice = GetChoice(5);

                switch (choice)
                {
                    case 1:
                        AddNewCustomer();
                        break;
                    case 2:
                        AddNewTitle();
                        break;
                    case 3:
                        ViewAllCustomers();
                        break;
                    case 4:
                        ViewAllRentals();
                        break;
                    case 5:
                        return;
                }
            }
        }

        static void AddNewCustomer()
        {
            Console.Write("Enter customer name: ");
            string name = Console.ReadLine();
            int year;
            while (true)
            {
                Console.Write("Enter registration year: ");
                if (int.TryParse(Console.ReadLine(), out year) && year <= DateTime.Now.Year)
                {
                    break;
                }
                Console.WriteLine("Invalid year. Please enter a valid year.");
            }

            customers.Add(new Customer { Name = name, RegistrationYear = year, Rentals = 0, MoneySpent = 0 });
            Console.WriteLine("Customer added successfully!");
        }

        static void AddNewTitle()
        {
            Console.Write("Enter title name: ");
            string name = Console.ReadLine();
            MediaType type;
            while (true)
            {
                Console.Write("Enter media type (VHS, CD, DVD): ");
                if (Enum.TryParse(Console.ReadLine(), true, out type) && Enum.IsDefined(typeof(MediaType), type))
                {
                    break;
                }
                Console.WriteLine("Invalid media type. Please enter VHS, CD, or DVD.");
            }
            Console.Write("Enter genre: ");
            string genre = Console.ReadLine();
            double price;
            while (true)
            {
                Console.Write("Enter rental price: ");
                if (double.TryParse(Console.ReadLine(), out price) && price > 0)
                {
                    break;
                }
                Console.WriteLine("Invalid price. Please enter a positive number.");
            }

            titles.Add(new Title { Name = name, Type = type, Genre = genre, Price = price });
            Console.WriteLine("Title added successfully!");
        }

        static void ViewAllCustomers()
        {
            Console.WriteLine("\nAll Customers:");
            foreach (var customer in customers)
            {
                Console.WriteLine(customer);
            }
        }

        static void ViewAllRentals()
        {
            Console.WriteLine("All Rentals:");
            foreach (var rental in rentals)
            {
                Console.WriteLine(rental);
            }
        }

        static void RentTitles()
        {
            if (titles.Count == 0)
            {
                Console.WriteLine("No titles available for rent.");
                Console.WriteLine("Press any key to return to the main menu...");
                Console.ReadKey();
                return;
            }

            Console.Write("Enter customer name: ");
            string name = Console.ReadLine();
            var customer = customers.Find(c => c.Name == name);

            if (customer == null)
            {
                Console.WriteLine("Customer not found. Creating new customer profile.");
                int year;
                while (true)
                {
                    Console.Write("Enter registration year: ");
                    if (int.TryParse(Console.ReadLine(), out year) && year <= DateTime.Now.Year)
                    {
                        break;
                    }
                    Console.WriteLine("Invalid year. Please enter a valid year.");
                }

                int rentals;
                while (true)
                {
                    Console.Write("Enter the number of rentals: ");
                    if (int.TryParse(Console.ReadLine(), out rentals) && rentals >= 0)
                    {
                        break;
                    }
                    Console.WriteLine("Invalid number of rentals. Please enter a valid amount.");
                }

                customer = new Customer { Name = name, RegistrationYear = year, Rentals = rentals, MoneySpent = 0 };
                customers.Add(customer);
            }
            else
            {
                int rentalsCount;
                while (true)
                {
                    Console.Write("Enter the number of rentals this customer has: ");
                    if (int.TryParse(Console.ReadLine(), out rentalsCount) && rentalsCount >= 0)
                    {
                        customer.Rentals = rentalsCount;
                        break;
                    }
                    Console.WriteLine("Invalid number of rentals. Please enter a valid amount.");
                }
            }

            List<Title> rentedTitles = new List<Title>();
            double totalCost = 0;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Available Media Types:");
                Console.WriteLine("1. VHS");
                Console.WriteLine("2. CD");
                Console.WriteLine("3. DVD");
                Console.WriteLine("4. Checkout");

                int mediaChoice = GetChoice(4);

                if (mediaChoice == 4)
                {
                    break;
                }

                MediaType selectedType = (MediaType)(mediaChoice - 1);
                Console.Clear();
                Console.WriteLine($"Available {selectedType} Titles:");
                var typeTitles = titles.Where(t => t.Type == selectedType).ToList();
                for (int i = 0; i < typeTitles.Count; i++)
                {
                    Console.WriteLine($" {i + 1}.{typeTitles[i].Name}, Genre: {typeTitles[i].Genre}, Price: {typeTitles[i].Price:C}");
                }

                Console.WriteLine($"{typeTitles.Count + 1}. Back");

                int titleChoice = GetChoice(typeTitles.Count + 1);

                if (titleChoice == typeTitles.Count + 1)
                {
                    continue;
                }

                var title = typeTitles[titleChoice - 1];
                rentedTitles.Add(title);
                totalCost += title.Price;


                Console.Clear();
                Console.WriteLine("Would you like to:");
                Console.WriteLine("1. Rent another title");
                Console.WriteLine("2. Checkout");

                int nextChoice = GetChoice(2);
                if (nextChoice == 2)
                {
                    break;
                }
            }

            double discount = CalculateDiscount(customer);
            int freeRentals = CalculateFreeRentals(customer);
            List<string> rewards = CalculateRewards(customer);

            double discountAmount = totalCost * discount;
            totalCost -= discountAmount;

            Console.Clear();
            Console.WriteLine("Checkout Summary");
            Console.WriteLine("Rented Titles:");
            foreach (var title in rentedTitles)
            {
                Console.WriteLine($"Name: {title.Name}, Type: {title.Type}, Price: {title.Price:C}");
            }
            Console.WriteLine(" ");
            Console.WriteLine($"Total Cost: {totalCost:C}");
            Console.WriteLine($"Discount: {discountAmount:C} ({discount * 100}%)");
            Console.WriteLine(" ");
            Console.WriteLine($"Free Rentals: {freeRentals}");
            Console.WriteLine("Rewards: " + string.Join(", ", rewards));

            customer.Rentals += rentedTitles.Count;
            customer.MoneySpent += totalCost;
            rentals.Add(new Rental { Customer = customer, Titles = rentedTitles, TotalCost = totalCost });

            Console.WriteLine("-----------------------------------------------------------------------------------------------------");
            Console.WriteLine("Thank you for your rental!");
            Console.WriteLine("Press any key to return to the main menu...");
            Console.ReadKey();
        

    }

    static double CalculateDiscount(Customer customer)
        {
            int years = DateTime.Now.Year - customer.RegistrationYear;
            if (years >= 15) return 0.35;
            if (years >= 10) return 0.20;
            if (years >= 5) return 0.10;
            return 0.05;
        }

        static int CalculateFreeRentals(Customer customer)
        {
            if (customer.Rentals >= 75) return 8;
            if (customer.Rentals >= 50) return 4;
            if (customer.Rentals >= 25) return 2;
            if (customer.Rentals >= 10) return 1;
            return 0;
        }

        static List<string> CalculateRewards(Customer customer)
        {
            List<string> rewards = new List<string>();
            int years = DateTime.Now.Year - customer.RegistrationYear;

            if (years >= 5 && customer.Rentals >= 25)
            {
                if (years >= 15 && customer.Rentals >= 75)
                {
                    rewards.Add("5 Bronze-tier");
                    rewards.Add("2 Silver-tier");
                    rewards.Add("1 Gold-tier");
                }
                else if (years >= 10 && customer.Rentals >= 50)
                {
                    rewards.Add("3 Bronze-tier");
                    rewards.Add("1 Silver-tier");
                }
                else if (years >= 5 && customer.Rentals >= 25)
                {
                    rewards.Add("1 Bronze-tier");
                }
            }

            return rewards;
        }

        static int GetChoice(int max)
        {
            int choice;
            while (true)
            {
                Console.Write("Enter your choice: ");
                if (int.TryParse(Console.ReadLine(), out choice) && choice >= 1 && choice <= max)
                {
                    break;
                }
                Console.WriteLine($"Invalid choice. Please enter a number between 1 and {max}.");
            }
            return choice;
        }
    }

   
    }
}



